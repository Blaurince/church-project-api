export const credentials =  {
  "type": "service_account",
  "project_id": "church-project-api",
  "private_key_id": "cc67ecc3fb115b12b227696aef063f79660263e8",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCnnNN5K6a4CRMl\nvyPuxztAbJEPjoY02QBXp5805P5AntNlMBZexawwM8RJVWeKrDLfRWZxZxhm7aFN\nUmBUXZybgwgN0EqJDnwF0z7yAaXYb1rnui6a7p5O0Q81PuXqhCVKOnfKYk3iMg0J\nhtsGXwS5YdJW6FGQz0dXu17RVRpQBFUhA3Hz4jfeQ6mmGzuWHNIC0y0VTq31SpvJ\n0FUn9zsRK6/oAUjzfQItvVi73NN02QRtBznh4A0DBoQvUxi50xOHU0fk0UBXcyCu\n0VNKPAB62XeKEh/e5qdpMQOD/SFgaSEf24sPFsXHk2N5eeyM6XRdiuFsio4TgEhT\njjQdH6upAgMBAAECggEAAjvnX6qSxsosLKkfB/w00HeB+XSbWlH4HLL5vsE8mEzl\noWgiLDIzSNMvzxBp2GHSLcKlimZm31xUdYzfBtDWmQYGkfSQQcJlKci2gpA+DyPw\n0LzdCSicCI3lx35mnxkSzCn6VcK4qgajwNhAzBVxIS1qGclv6N+yYjt3mI+rUZyv\npbsTpdI85Yg8xwrYW0HFA7CesoFh6NM6jOD9K+cRZAocs5ncaYfcwUsIKcRz9JVg\n8qU94h+i/0V/4dq37JulnjjJA0/DPCJsdDxBalnFQJCa7OZwnqh4oQ6qQJNYAkF5\nr3cD76Dxs2kyWr9Dck8JJo7CbgkjbvTWxP8U4gDC3wKBgQDUdRkwhYNllZD6MHVm\nOjYOfCs1Dj3VOJOz3fMDPh4i1zFPBXsa4u4iZ3+sLs4lda46ifMMwNlvDw46I5wp\na2holCFeZJ2zGNfEitkXKXFmLyoly6BEWQccIf0KJgMQsIC10l+JF4WJkJVL9icd\nX1lnJUel79zSCrCmtA8GFkZx7wKBgQDJ9uBTobEcf8GwHDls/qrAKuJ4W3KcmKA6\nruTHUkI432rZIRO7EJ/J5RN79aaSuu33c/LB50jQ+YoMZYMgJ2q/gOytifBHFWIv\nQOwstelYZvuFeEsE9tOXI6elxUHX8ru+HRGBHm9J4p4ISiO21Om+gIgbv6BDHRmQ\n91Do1ifz5wKBgGQCY0Ml9j5hc4dyPDFNAZk79hLZi13NbinjNru2B/Wamsl56QM1\nA6gKVF03Ay87ADLqMRE1zqSqz6WqkZ4lw1ZHNJX8gweFkDwiqCJxDcJuPUbhXaYO\nynwBu92FGzhF/bCZQQOFoQSqnLzPOIZpFeqp79o62RW+ln1CkTfqUGrdAoGAK6L7\ntRYqfk3cO4Ddp38exYZ+iCK6ELupYwSGycosJL2hCGjtKm3dGHI2U4IwC2P4Jo8W\n1G50fTJtcWA9hKT/m4Dvok87ayBjpnIQlVh4onEdxyjGjLwH25AImPiV0WLQzbLa\nJVu+D+i23HOoY8h8+Hws7FHq/pU7AOduw+ABoeECgYAIqQ8YECxhgS75ecBg7Ogd\nIkEgBps/OI7QagF6kyngE/BJ0d+OProyx2irJIbI2regaRCalK+4IlQ1Qt4yQDDs\nqQ8r9xCS5M2s6fPC8/TQoEECqQfwtRBhAJT3KvXZ7YrSUQ9hklgmz0fJogimfGB/\ncEUXpBB/ZWzScwLUh7yAFw==\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-dqpzx@church-project-api.iam.gserviceaccount.com",
  "client_id": "110988336141425743521",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-dqpzx%40church-project-api.iam.gserviceaccount.com"
}
